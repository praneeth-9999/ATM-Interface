package Deposit;
import java.util.*;
interface Deposit
{
	public double deposit();
}
public class Deposition implements Deposit
{
	public double deposit()
	{
		double amount;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the amount for deposition:");
		amount=sc.nextDouble();
		System.out.println("Amount successfully deposited..");
		return amount;
	}
}
		
		
		
	