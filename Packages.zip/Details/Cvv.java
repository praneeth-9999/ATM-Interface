package Details;
import java.util.*;
interface Verifycvv
{
	public int cvvno();
}
public class Cvv implements Verifycvv
{
	public int cvvno()
	{
		Scanner sc=new Scanner(System.in);
		int cvv;
		boolean a=false;
		System.out.println("enter your cvv no.:");
		cvv=sc.nextInt();
		String s=Integer.toString(cvv);
		while(true)
		{
			if(s.length()==3)
			{
				for(int i=0;i<s.length();i++)
				{
					if(s.charAt(i)>='0' && s.charAt(i)<='9')
					{
						a=true;
					}
				}	
				if(a)
				{
					return cvv;
				}
			}
			else
			{
				System.out.println("enter the correct cvv number!!");
				return 0;
			}
		}
	}
}
			
			