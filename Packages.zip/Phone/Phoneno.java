package Phone;
import java.util.*;
interface PHN
{
	public String phone();
}
public class Phoneno implements PHN
{
	public String phone()
	{
		String pho;
		boolean a=false;
		while(true)
		{
			Scanner sc=new Scanner(System.in);
			System.out.println("enter your phone number");
			pho=sc.nextLine();
			if(pho.length()==10)
			{
				for(int i=0;i<10;i++)
				{
					if((pho.charAt(i)>='0')&&(pho.charAt(i)<='9'))
					{
						a=true;
					}
				}
				if(a==true)
				{
					return pho;
				}
			}
			else
			{
				System.out.println("Enter correct phone number..!!!");
			}
		}
	}
}
				